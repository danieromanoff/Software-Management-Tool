package softwaremanagementtool.agile.db;

public class AgileDatabase {

}
