package softwaremanagementtool.agile.db;

public class AgileXmlDatabase {

}
