package softwaremanagementtool.agile;

public class SprintTask {

}
