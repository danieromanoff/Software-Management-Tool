/**
 * 
 */
package softwaremanagementtool.agile.changereqview;

/**
 * @author Stephen
 *
 */
public class ChangeReqViewController {

}
