package softwaremanagementtool.agile;

import java.io.IOException;
import softwaremanagementtool.agile.userstoryview.UserStoryEditDialogController;
import softwaremanagementtool.agile.userstoryview.UserStoryOverviewController;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class MainApp extends Application 
{
    private Stage primaryStage;
    private BorderPane rootLayout;
    
    //user story data as an observable list of user stories.
    private ObservableList<UserStory> userstoryData = FXCollections.observableArrayList();

    //Constructor
    public MainApp() {
    	// default data - as an example
    	userstoryData.add(new UserStory(1,"Title 1", "Owner 1"));
    }
    // display the list of the user story
    public ObservableList<UserStory> getUserStoryData() {
        return userstoryData;
    }

    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        this.primaryStage.setTitle("User Story Manager");

        initRootLayout();

        showUserStoryOverview();
    }

    //starting the root layout
    public void initRootLayout() 
    {
        try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MainApp.class.getResource("userstoryview/RootLayout.fxml"));
            rootLayout = (BorderPane) loader.load();
            Scene scene = new Scene(rootLayout);
            primaryStage.setScene(scene);
            primaryStage.show();
        } 
        //std. exception 
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    // user story default view
    public void showUserStoryOverview() 
    {
        try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MainApp.class.getResource("userstoryview/UserStoryOverview.fxml"));
            AnchorPane userstoryOverview = (AnchorPane) loader.load();
            rootLayout.setCenter(userstoryOverview);
            UserStoryOverviewController controller = loader.getController();
            controller.setMainApp(this);

        } 
        catch (IOException e) 
        {
            e.printStackTrace();
        }
    }

    //opens the editor window to edit the user story
    public boolean showUserStoryEditDialog(UserStory userstory) 
    {
        try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MainApp.class.getResource("userstoryview/UserStoryEditDialog.fxml"));
            AnchorPane page = (AnchorPane) loader.load();
            Stage dialogStage = new Stage();
            dialogStage.setTitle("Edit User Story");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(primaryStage);
            Scene scene = new Scene(page);
            dialogStage.setScene(scene);
            UserStoryEditDialogController controller = loader.getController();
            controller.setDialogStage(dialogStage);
            controller.setUserStory(userstory);
            //showandwait method to keep the window open till the completion of user action
            dialogStage.showAndWait();
            return controller.isOkClicked();
        } 
        catch (IOException e) 
        {
            e.printStackTrace();
            return false;
        }
    }

    public Stage getPrimaryStage() {
        return primaryStage;
    }

    public static void main(String[] args) {
        launch(args);
    }
}