package softwaremanagementtool.agile;

public class ChangeRequest {

}
