package softwaremanagementtool.agile;

public class Sprint {

}
