/**
 * 
 */
package softwaremanagementtool.agile.sprintview;

/**
 * @author Stephen
 *
 */
public class SprintViewController {

}
