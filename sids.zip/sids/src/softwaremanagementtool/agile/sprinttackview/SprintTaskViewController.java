/**
 * 
 */
package softwaremanagementtool.agile.sprinttackview;

/**
 * @author Stephen
 *
 */
public class SprintTaskViewController {

}
