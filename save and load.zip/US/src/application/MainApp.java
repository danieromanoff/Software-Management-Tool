package application;
import java.io.File;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import static java.util.concurrent.TimeUnit.*;
import java.io.IOException;

import java.util.prefs.Preferences;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import application.UserStory; //Person = Userstory
import application.UserStoryWrapper;
import application.view.UserStoryEditDialogController;
import application.view.UserStoryOverviewController;
import application.view.RootLayoutController;

public class MainApp extends Application 
{
    private Stage primaryStage;
    private BorderPane rootLayout;
    
    //user story data as an observable list of user stories.
    
    private ObservableList<UserStory> userstoryData = FXCollections.observableArrayList();
    private final static ScheduledExecutorService scheduler =Executors.newScheduledThreadPool(1);

    //Constructor
    
    public MainApp() 
    
    {
    	
    	// default data - as an example
    	userstoryData.add(new UserStory(1,"Title 1", "Owner 1"));
    	userstoryData.add(new UserStory(2,"Title 2", "Owner 2"));
    	userstoryData.add(new UserStory(3,"Title 3", "Owner 3"));
    	userstoryData.add(new UserStory(4,"Title 4", "Owner 4"));
    	userstoryData.add(new UserStory(5,"Title 5", "Owner 5"));
    	
    	//calling autosave function
    	
    	savingafter();
    }
    
    // display the list of the user story
    
    public ObservableList<UserStory> getUserStoryData() 
    {
        return userstoryData;
    }

    @Override
    public void start(Stage primaryStage) 
    
    // starting of the application window
    {
        this.primaryStage = primaryStage;
        this.primaryStage.setTitle("User Story Manager");
        initRootLayout();
        showUserStoryOverview();
    }

    //starting the root layout
    
    public void initRootLayout() 
    {
        try 
        {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MainApp.class.getResource("view/RootLayout.fxml"));
            rootLayout = (BorderPane) loader.load();
            Scene scene = new Scene(rootLayout);
            primaryStage.setScene(scene);
            // Giving controller access to the MainApp.
            RootLayoutController controller = loader.getController();
            controller.setMainApp(this);
            primaryStage.show();
        } 
        
        //Handling exception 
        
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    //default user story view
    
    public void showUserStoryOverview() 
    {
        try 
        {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MainApp.class.getResource("view/UserStoryOverview.fxml"));
            AnchorPane userstoryOverview = (AnchorPane) loader.load();
            rootLayout.setCenter(userstoryOverview);
            UserStoryOverviewController controller = loader.getController();
            controller.setMainApp(this);
        } 
        
        //Handling exception 
        
        catch (IOException e) 
        {
            e.printStackTrace();
        }
    }

    //Opening editor window to edit the user story
    
    public boolean showUserStoryEditDialog(UserStory userstory) 
    {
        try 
        {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MainApp.class.getResource("view/UserStoryEditDialog.fxml"));
            AnchorPane page = (AnchorPane) loader.load();
            Stage dialogStage = new Stage();
            dialogStage.setTitle("Edit User Story");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(primaryStage);
            Scene scene = new Scene(page);
            dialogStage.setScene(scene);
            UserStoryEditDialogController controller = loader.getController();
            controller.setDialogStage(dialogStage);
            controller.setUserStory(userstory);
            //showandwait method used to keep the current window open till the completion of user action
            dialogStage.showAndWait();
            return controller.isOkClicked();
        } 
        
        //Handling exception 
        
        catch (IOException e) 
        {
            e.printStackTrace();
            return false;
        }
    }

    // getting file path of the user story file
    public File getUserStoryFilePath() 
    {
        Preferences prefs = Preferences.userNodeForPackage(MainApp.class);
        String filePath = prefs.get("filePath", null);
        if (filePath != null) 
        {
            return new File(filePath);
        } else 
        {
            return null;
        }
    }

    // setting user story file path to variable
    public void setUserStoryFilePath(File file) 
    {
        Preferences prefs = Preferences.userNodeForPackage(MainApp.class);
        if (file != null) {
            prefs.put("filePath", file.getPath());
            primaryStage.setTitle("User story App - " + file.getName());
        } else 
        {
            prefs.remove("filePath");
            primaryStage.setTitle("User story App");
        }
    }
   
    // loading user story data from the saved file
    
    public void loadUserStoryDataFromFile(File file) {
        try {
            JAXBContext context = JAXBContext.newInstance(UserStoryWrapper.class);
            
            //Unmarshaller method used to load the data from the xml file
            
            Unmarshaller um = context.createUnmarshaller();
            UserStoryWrapper wrapper = (UserStoryWrapper) um.unmarshal(file);
            userstoryData.clear();
            userstoryData.addAll(wrapper.getUS()); 

            // Save the file path to the registry.
            
            setUserStoryFilePath(file);

        } 
        
        // catches ANY exception
        catch (Exception e)
        
        {
        	Alert alert = new Alert(AlertType.ERROR);
        	alert.setTitle("Error");
        	alert.setHeaderText("Could not load data");
        	alert.setContentText("Could not load data from file:\n" + file.getPath());
        	alert.showAndWait();
        }
    }

    //saving data to xml file
    public void saveUserStoryDataToFile(File file) 
    {
       try 
       {
            JAXBContext context = JAXBContext.newInstance(  UserStoryWrapper.class);
            
            //marshaller method used to save the data from the xml file
            
            Marshaller m = context.createMarshaller();
            m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

            // Wrapping our person data.
            UserStoryWrapper wrapper = new UserStoryWrapper();
            wrapper.setUS(userstoryData);
            m.marshal(wrapper, file);

            // Save the file path to the registry.
            setUserStoryFilePath(file);
        } 
       // catches ANY exception
       
       catch (Exception e) 
       { 
        	Alert alert = new Alert(AlertType.ERROR);
        	alert.setTitle("Error");
        	alert.setHeaderText("Could not save data");
        	alert.setContentText("Could not save data to file:\n" + file.getPath());
        	alert.showAndWait();
        }
    }
    public Stage getPrimaryStage() 
    {
        return primaryStage;
    }
    
    //autosaving the file after certain time period
    
    
    public void savingafter() 
    {
	     final Runnable saver = new Runnable() 
	     {
	    	 public void run() 
	    	 {
	    		 autosave(); 
	    	 }
	     };
	     final ScheduledFuture<?> beeperHandle =
	     scheduler.scheduleAtFixedRate(saver, 10, 10, SECONDS);
	     scheduler.schedule(new Runnable() {
	     public void run() 
	     { beeperHandle.cancel(true); }}, 60 * 60, SECONDS);
	   }
    public void autosave()
    {
    	File userstoryFile = getUserStoryFilePath();
        if (userstoryFile != null) 
        {	
            saveUserStoryDataToFile(userstoryFile);
        }
        else 
        {
          //handleSaveAs();
        }
    }
    public static void main(String[] args) 
    {
    	launch(args);   
    }
}