package application;

import java.util.List;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/*
 *class  to wrap a list of US( user story ). This is used for saving the list of US( user story ) to XML.
 */

@XmlRootElement(name = "US")
public class UserStoryWrapper 
{
    private List<UserStory> US;

    @XmlElement(name = "US")
    public List<UserStory> getUS() 
    {
        return US;
    }
    public void setUS(List<UserStory> US) 
    {
        this.US = US;
    }
}